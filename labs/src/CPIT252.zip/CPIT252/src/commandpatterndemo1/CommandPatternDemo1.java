/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package commandpatterndemo1;

/**
 *
 * @author 2135155
 */
public class CommandPatternDemo1 {

    public static void main(String[] args) {
        Document doc = new Document();
        Command1 clickOpen = new DocumentOpen(doc);
        Command1 clickSave = new DocumentSave(doc);

        MenuOption menu = new MenuOption(clickOpen, clickSave);

        menu.clickOpen();
        menu.clickSave();
    }
}
