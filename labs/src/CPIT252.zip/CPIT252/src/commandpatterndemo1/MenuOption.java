/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package commandpatterndemo1;

/**
 *
 * @author 2135155
 */
public class MenuOption {

    private Command1 openCommand;
    private Command1 saveCommand;

    public MenuOption(Command1 open, Command1 save) {
        this.openCommand = open;
        this.saveCommand = save;
    }

    public void clickOpen() {
        openCommand.execute();
    }

    public void clickSave() {
        saveCommand.execute();
    }
}
