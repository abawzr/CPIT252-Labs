/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package commandpatterndemo1;

/**
 *
 * @author 2135155
 */
public class DocumentOpen implements Command1 {

    private Document doc;

    public DocumentOpen(Document doc) {
        this.doc = doc;
    }

    @Override
    public void execute() {
        doc.open();
    }
}
