package proxypatterndemo2;

public interface Pizza {

    public void name();

    public void size();

    public void price();
}
