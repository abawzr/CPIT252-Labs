package proxypatterndemo2;

public class ProxyPizza extends PizzaSubject {

    @Override
    public void name() {
        super.name();
    }

    @Override
    public void size() {
        super.size();
    }

    @Override
    public void price() {
        super.price();
    }
}
