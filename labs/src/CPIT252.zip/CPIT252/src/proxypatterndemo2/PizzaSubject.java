package proxypatterndemo2;

public class PizzaSubject implements Pizza {

    @Override
    public void name() {
        System.out.print("Veg Pizza is available");
    }

    @Override
    public void size() {
        System.out.print(" in a standard size and price in SAR is: ");
    }

    @Override
    public void price() {
        System.out.print("150\n");
    }

}
