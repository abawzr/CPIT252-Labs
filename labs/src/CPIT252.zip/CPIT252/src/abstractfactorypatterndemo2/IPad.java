package abstractfactorypatterndemo2;

public class IPad extends Tablet {

    public IPad() {
        name = "iPad";
    }

    public void prepare() {
        System.out.println("Creating " + name);
        System.out.println("Adding Apple Pay features");
    }
}
