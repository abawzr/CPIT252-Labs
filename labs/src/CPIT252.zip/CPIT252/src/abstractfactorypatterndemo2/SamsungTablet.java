package abstractfactorypatterndemo2;

public class SamsungTablet extends Tablet {

    public SamsungTablet() {
        name = "Samsung Tablet";
    }

    public void prepare() {
        System.out.println("Creating " + name);
        System.out.println("Adding Samsung Pay features");
    }
}
