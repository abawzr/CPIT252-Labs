/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package observerpatterndemo1;

/**
 *
 * @author 2135155
 */
public class ObserverPatternDemo1 {

    public static void main(String[] args) {
        Employee emp = new Employee(10, "Burhan Rizwan", 2000);
        new HumanResourcesObs(emp);
        new HighManagementObs(emp);
        emp.setSalary(2200);
        System.out.println("-----------------------------------------------");
        emp.setSalary(3300);
    }
}
