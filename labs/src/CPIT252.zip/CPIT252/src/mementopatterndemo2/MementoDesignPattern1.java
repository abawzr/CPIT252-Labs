/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mementopatterndemo2;

/**
 *
 * @author 2135155
 */
public class MementoDesignPattern1 {

    public static void main(String[] args) {
        Originator originator = new Originator();
        originator.setState("Lion");
        Memento memento = originator.createMemento();
        Caretaker caretaker = new Caretaker();
        caretaker.addMemento(memento);
        originator.setState("Tiger");
        originator.setState("Horse");
        memento = originator.createMemento();
        caretaker.addMemento(memento);
        originator.setState("Elephant");
        System.out.println("Originator Current State: " + originator.getState());
        System.out.println("Originator restoring to previous state...");
        memento = caretaker.getMemento(1);
        originator.setMemento(memento);
        System.out.println("Originator Current State: " + originator.getState());
        System.out.println("Again restoring to previous state...");
        memento = caretaker.getMemento(0);
        originator.setMemento(memento);
        System.out.println("Originator Current State: " + originator.getState());
    }
}
