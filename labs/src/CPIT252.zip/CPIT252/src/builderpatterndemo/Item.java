package builderpatterndemo;

public interface Item {

    public String name();

    public String size();

    public int price();
}
