package builderpatterndemo;

public class SmallVegPizza extends VegPizza {

    @Override
    public String name() {
        return "Small Veg Pizza";
    }

    @Override
    public String size() {
        return "Small Size";
    }

    @Override
    public int price() {
        return 120;
    }

}
