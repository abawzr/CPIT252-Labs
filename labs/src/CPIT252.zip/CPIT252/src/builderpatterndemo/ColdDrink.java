package builderpatterndemo;

public abstract class ColdDrink implements Item {

    @Override
    public abstract int price();

    @Override
    public abstract String size();

    @Override
    public abstract String name();

}
