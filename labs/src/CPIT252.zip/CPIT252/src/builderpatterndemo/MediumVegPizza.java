package builderpatterndemo;

public class MediumVegPizza extends VegPizza {

    @Override
    public String name() {
        return "Medium Veg Pizza";
    }

    @Override
    public String size() {
        return "Medium Size";
    }

    @Override
    public int price() {
        return 150;
    }
}
