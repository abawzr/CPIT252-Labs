package builderpatterndemo;

public class LargeNonVegPizza extends NonVegPizza {

    @Override
    public String name() {
        return "Large Non Veg Pizza";
    }

    @Override
    public String size() {
        return "Large Size";
    }

    @Override
    public int price() {
        return 220;
    }

}
