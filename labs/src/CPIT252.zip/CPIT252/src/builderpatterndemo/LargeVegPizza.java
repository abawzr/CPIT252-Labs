package builderpatterndemo;

public class LargeVegPizza extends VegPizza {

    @Override
    public String name() {
        return "Large Veg Pizza";
    }

    @Override
    public String size() {
        return "Large Size";
    }

    @Override
    public int price() {
        return 180;
    }
}
