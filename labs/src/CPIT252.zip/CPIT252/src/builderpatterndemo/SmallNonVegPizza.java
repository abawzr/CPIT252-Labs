package builderpatterndemo;

public class SmallNonVegPizza extends NonVegPizza {

    @Override
    public String name() {
        return "Small Non Veg Pizza";
    }

    @Override
    public String size() {
        return "Small Size";
    }

    @Override
    public int price() {
        return 180;
    }

}
