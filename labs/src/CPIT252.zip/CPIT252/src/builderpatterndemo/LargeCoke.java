package builderpatterndemo;

public class LargeCoke extends Coke {

    @Override
    public String name() {
        return "Large Coke";
    }

    @Override
    public String size() {
        return "Large Size";
    }

    @Override
    public int price() {
        return 50;
    }

}
