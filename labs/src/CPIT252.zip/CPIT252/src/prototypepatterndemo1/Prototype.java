package prototypepatterndemo1;

public interface Prototype {

    public Prototype getClone();
}
