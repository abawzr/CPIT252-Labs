package abstractfactorypatterndemo1;

public interface AbstractFactory {
    
    public Degree calculateTotalFee();
    
    public Diploma calculatetotalFee();
    
}
