package abstractfactorypatterndemo1;

public class CSDegree extends Degree {

    public CSDegree() {
        duration = 4;
        fee = 6000;
    }

    @Override
    void compute() {
        System.out.println("The fee of CS degree is: " + (duration * fee) + " SAR \n");
    }
}
