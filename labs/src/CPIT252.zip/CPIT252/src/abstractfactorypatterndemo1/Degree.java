package abstractfactorypatterndemo1;

public abstract class Degree {

    int fee;
    int duration;

    abstract void compute();
}
