package abstractfactorypatterndemo1;

public class ITDegree extends Degree {

    public ITDegree() {
        duration = 4;
        fee = 3000;
    }

    @Override
    void compute() {
        System.out.println("The fee of IT degree is: " + (duration * fee) + " SAR \n");
    }

}
