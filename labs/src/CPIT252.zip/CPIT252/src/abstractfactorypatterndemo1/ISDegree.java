package abstractfactorypatterndemo1;

public class ISDegree extends Degree {

    public ISDegree() {
        duration = 3;
        fee = 6500;
    }

    @Override
    public void compute() {
        System.out.println("The IS Degree fee is: " + duration * fee + " SAR \n");
    }
}
