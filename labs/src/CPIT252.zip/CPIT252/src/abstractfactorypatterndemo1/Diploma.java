package abstractfactorypatterndemo1;

public abstract class Diploma {

    int fee;
    int duration;

    void compute() {
        System.out.println(duration * fee);
    }
}
