/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package commandpatterndemo2;

/**
 *
 * @author 2135155
 */
public class CommandPatternDemo2 {

    public static void main(String[] args) {
        Light livingRoomLight = new Light();

        Command lightsOn = new LightOnCommand(livingRoomLight);
        Command lightsOff = new LightOffCommand(livingRoomLight);

        RemoteControl remote = new RemoteControl(lightsOn);
        remote.pressButton();

        remote = new RemoteControl(lightsOff);
        remote.pressButton();
    }
}
