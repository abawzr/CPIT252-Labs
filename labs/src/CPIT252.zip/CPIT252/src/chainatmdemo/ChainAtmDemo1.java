/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chainatmdemo;

import java.util.Scanner;

/**
 *
 * @author 2135155
 */
public class ChainAtmDemo1 {

    private DispenseChain c1;
    
    public ChainAtmDemo1() {
        this.c1 = new Riyal50Dispenser();
        DispenseChain c2 = new Riyal20Dispenser();
        DispenseChain c3 = new Riyal10Dispenser();
        
        c1.setNextChain(c2);
        c2.setNextChain(c3);
    }
    
    public static void main(String[] args) {
        ChainAtmDemo1 atmDispenser = new ChainAtmDemo1();
        while (true) {
            int amount = 0;
            System.out.println("Enter amount to dispense: ");
            Scanner in = new Scanner(System.in);
            amount = in.nextInt();
            if (amount % 10 != 0) {
                System.out.println("Amount should be in a multiple of 10s.");
                return;
            }
            atmDispenser.c1.dispense(new Currency(amount));
        }
    }
}
