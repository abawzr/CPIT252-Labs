/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mementopatterndemo1;

/**
 *
 * @author 2135155
 */
public class Life {

    private String time;

    public void set(String time) {
        System.out.println("Setting time to " + time);
        this.time = time;
    }

    public Memento SaveToMemento() {
        System.out.println("Saving time to Memento");
        return new Memento(time);
    }

    public void restoreFromMemento(Memento memento) {
        time = memento.getSavedTime();
        System.out.println("Time restored from Memento: " + time);
    }

    public static class Memento {

        private final String time;

        public Memento(String timeToSave) {
            time = timeToSave;
        }

        public String getSavedTime() {
            return time;
        }
    }
}
