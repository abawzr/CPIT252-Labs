/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mementopatterndemo1;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 2135155
 */
public class MementoPatternDemo1 {
    
    public static void main(String[] args) {
        List<Life.Memento> savedTimes = new ArrayList<Life.Memento>();
        
        Life life = new Life();
        
        life.set("2000 B.C.");
        savedTimes.add(life.SaveToMemento());
        
        life.set("2000 A.D.");
        savedTimes.add(life.SaveToMemento());
        
        life.set("3000 A.D.");
        savedTimes.add(life.SaveToMemento());
        
        life.set("4000 A.D.");
        
        life.restoreFromMemento(savedTimes.get(0));
    }
}
