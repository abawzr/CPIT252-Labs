package proxypatterndemo1;

public class Rectangle extends Circle {

    @Override
    public void display() {
        System.out.println("The Rectangle child class acts as proxy\n");
        super.display();
    }
}
