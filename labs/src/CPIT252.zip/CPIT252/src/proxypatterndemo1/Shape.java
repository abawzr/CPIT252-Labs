package proxypatterndemo1;

public interface Shape {

    public void display();
}
