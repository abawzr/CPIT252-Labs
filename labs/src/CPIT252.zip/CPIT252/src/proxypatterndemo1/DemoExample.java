package proxypatterndemo1;

public class DemoExample {

    public static void main(String[] args) {
        Rectangle shape = new Rectangle();
        shape.display();
    }
}
