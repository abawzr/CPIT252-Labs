package labwork3_2135155_it1;

public interface Observer {

    void update();
}
