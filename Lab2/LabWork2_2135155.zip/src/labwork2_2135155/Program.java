package labwork2_2135155;

public interface Program {

    public String prepareProg();

    public double progPrice();
}
